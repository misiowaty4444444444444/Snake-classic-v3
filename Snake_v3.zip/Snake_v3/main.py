import tkinter as tk
import random

W = 600
H = 600
SIZE = 20


class SnakeGame:

    def __init__(self, root):
        self.root = root
        self.root.title("Snake Classic v3")

        self.canvas = tk.Canvas(root, width=W, height=H, bg="black")
        self.canvas.pack()

        self.score = 0
        self.direction = "Right"
        self.snake = [(100, 100)]
        self.food = self.spawn_food()

        self.game_over = False

        self.root.bind("<Key>", self.key)

        self.loop()

    # ---------------- FOOD ----------------

    def spawn_food(self):
        return (random.randint(0, (W//SIZE)-1)*SIZE,
                random.randint(0, (H//SIZE)-1)*SIZE)

    # ---------------- CONTROLS ----------------

    def key(self, e):
        k = e.keysym

        if k in ["Up", "w", "W"] and self.direction != "Down":
            self.direction = "Up"
        elif k in ["Down", "s", "S"] and self.direction != "Up":
            self.direction = "Down"
        elif k in ["Left", "a", "A"] and self.direction != "Right":
            self.direction = "Left"
        elif k in ["Right", "d", "D"] and self.direction != "Left":
            self.direction = "Right"

    # ---------------- LOOP ----------------

    def loop(self):
        if self.game_over:
            return

        head_x, head_y = self.snake[0]

        if self.direction == "Up":
            head_y -= SIZE
        elif self.direction == "Down":
            head_y += SIZE
        elif self.direction == "Left":
            head_x -= SIZE
        elif self.direction == "Right":
            head_x += SIZE

        new_head = (head_x, head_y)

        # ❌ ŚCIANY = DEATH (KLASYK)
        if head_x < 0 or head_x >= W or head_y < 0 or head_y >= H:
            self.die()
            return

        # ❌ CIAŁO = DEATH
        if new_head in self.snake:
            self.die()
            return

        self.snake.insert(0, new_head)

        # 🍎 JEDZENIE
        if new_head == self.food:
            self.score += 1
            self.food = self.spawn_food()
        else:
            self.snake.pop()

        self.draw()

        self.root.after(120, self.loop)

    # ---------------- DRAW ----------------

    def draw(self):
        self.canvas.delete("all")

        fx, fy = self.food
        self.canvas.create_rectangle(fx, fy, fx+SIZE, fy+SIZE, fill="red")

        for i, (x, y) in enumerate(self.snake):
            color = "lime" if i == 0 else "green"
            self.canvas.create_rectangle(x, y, x+SIZE, y+SIZE, fill=color)

        self.canvas.create_text(300, 20,
                                text=f"Score: {self.score}",
                                fill="white",
                                font=("Arial", 16))

    # ---------------- GAME OVER ----------------

    def die(self):
        self.game_over = True

        self.canvas.create_text(300, 300,
                                text="GAME OVER",
                                fill="red",
                                font=("Arial", 30, "bold"))

        self.root.after(1500, self.restart)

    def restart(self):
        self.score = 0
        self.snake = [(100, 100)]
        self.direction = "Right"
        self.food = self.spawn_food()
        self.game_over = False
        self.loop()


# RUN
if __name__ == "__main__":
    root = tk.Tk()
    game = SnakeGame(root)
    root.mainloop()